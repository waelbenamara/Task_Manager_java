import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Dashboard {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dashboard window = new Dashboard();
					window.frame.setVisible(true);
					
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Dashboard() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		double width = (int)screenSize.getWidth();
		double height = (int)screenSize.getHeight();
		frame.setSize((int)width, (int)height);
		frame.getContentPane().setLayout(null);
		
		JButton button = new JButton("Schedule");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Schedule sc = new Schedule();
				sc.main(null);
			}
		});
		button.setBounds(387, 53, 713, 125);
		frame.getContentPane().add(button);
		
		JButton btnNewButton_2 = new JButton("Calendar");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Calendar ca = new Calendar();
				ca.main(null);
			}
		});
		btnNewButton_2.setBounds(387, 202, 351, 159);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton button_1 = new JButton("Tasks");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Tasks ta = new Tasks();
				ta.main(null);
			}
		});
		button_1.setBounds(750, 202, 350, 159);
		frame.getContentPane().add(button_1);
		
		JButton button_2 = new JButton("Reminder");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Reminder re = new Reminder();
				re.main(null);
			}	
		});
		button_2.setBounds(387, 387, 351, 159);
		frame.getContentPane().add(button_2);
		
		JButton button_3 = new JButton("Assignments");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Assignments a = new Assignments();
				a.main(null);
			}	
		});
		button_3.setBounds(750, 387, 351, 159);
		frame.getContentPane().add(button_3);
		
		JButton button_4 = new JButton("About Us");
		button_4.setBounds(379, 596, 724, 39);
		frame.getContentPane().add(button_4);
		
		JButton button_5 = new JButton("Exit");
		button_5.setBackground(Color.WHITE);
		button_5.setBounds(379, 647, 724, 39);
		frame.getContentPane().add(button_5);
	
	}
}
